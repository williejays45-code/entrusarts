const canvas = document.getElementById('sceneCanvas');
const ctx = canvas.getContext('2d');
function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

const assets = {
  emblem: 'assets/emblem.png',
  ground: 'assets/ground.png',
  guardian: 'assets/guardian.png'
};
const images = {};
let animationStartTime = null;
let animationInProgress = false;

function loadAssets(callback) {
  let loaded = 0;
  const total = Object.keys(assets).length;
  Object.keys(assets).forEach(key => {
    const img = new Image();
    img.src = assets[key];
    img.onload = () => {
      images[key] = img;
      loaded++;
      if (loaded === total) callback();
    };
  });
}

function drawScene(progress) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const groundY = canvas.height * 0.6;
  ctx.drawImage(images.ground, 0, groundY, canvas.width, canvas.height - groundY);
  const emblemSize = 150 + 100 * progress;
  ctx.drawImage(images.emblem, canvas.width/2 - emblemSize/2, groundY - emblemSize, emblemSize, emblemSize);
  if (progress > 0.5) {
    const guardianSize = 300 * (progress - 0.5) * 2;
    ctx.drawImage(images.guardian, canvas.width/2 - guardianSize/2, groundY - guardianSize, guardianSize, guardianSize);
  }
}

function animate(timestamp) {
  if (!animationStartTime) animationStartTime = timestamp;
  const elapsed = timestamp - animationStartTime;
  const progress = Math.min(elapsed / 5000, 1);
  drawScene(progress);
  document.querySelector("#progressBarContainer").innerHTML = '<progress value="' + progress + '" max="1"></progress>';
  if (progress < 1) {
    requestAnimationFrame(animate);
  }
}

document.getElementById("startButton").addEventListener("click", () => {
  if (!animationInProgress) {
    animationInProgress = true;
    document.getElementById("overlay").classList.remove("show");
    animationStartTime = null;
    requestAnimationFrame(animate);
  }
});

window.onload = () => {
  loadAssets(() => {
    document.getElementById("volumeCardContainer").innerHTML = '<div class="volume-card">🔊 Volume: <input type="range" min="0" max="100" value="75" /></div>';
  });
}
